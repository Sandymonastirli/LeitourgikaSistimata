#include "syslib.h"

PUBLIC int sys_schedule(endpoint_t proc_ep,
			int priority,
			int quantum,
			int cpu,
			float fss_priority) //neo pedio
{
	
	//path: lib/libsys/sys_schedule.c
	message m;
	//apo ton SCHED ston kernel
	m.SCHEDULING_ENDPOINT = proc_ep;
	m.SCHEDULING_PRIORITY = priority;
	m.SCHEDULING_QUANTUM  = quantum;
	m.m9_l3 = fss_priority; //prosthesame sto mynhma to neo pedio
	m.SCHEDULING_CPU = cpu;
	return(_kernel_call(SYS_SCHEDULE, &m));
}



//SOS typoi mhnymatwn 10, kai oti diaferoun sta pedia (int, short, long, pointer)
//otan dhlwnoume ena mynhma tha einai enas apo autous tous 10 typous.


//Arxeio:include/minix/com.h  yparxoun ola ta pedia pou xrhsimopoioume
// These are used for SYS_SCHEDULE, a reply to SCHEDULING_NO_QUANTUM 
//#   define SCHEDULING_ENDPOINT  m9_l1
//#   define SCHEDULING_QUANTUM   m9_l2
//#   define SCHEDULING_PRIORITY  m9_s1
//#   define SCHEDULING_CPU       m9_l4
//Ara to mhnyma pou xrhsimopoiei einai typou 9
//xrhsimopoiei 3 long (ton l1,l2,l4) kai 1 short (s1)
//ara mporoume na xrhsimopoihsoume kapoio apo ta eleu8era, to valame sto l3

//fss_priority einai typou float, OMWS KANENA mhnyma den exei float. 
//ara to valame se long. Ousiastika xanoume oti dekadiko pshfio yphrxe.






